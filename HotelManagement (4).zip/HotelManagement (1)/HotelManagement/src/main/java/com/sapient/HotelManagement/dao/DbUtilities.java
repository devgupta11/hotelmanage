package com.sapient.HotelManagement.dao;

	

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

	public class DbUtilities {
	    private  static  final String driver_class="driver.class.name";
	    private static final String url="mysql.url";
	    private static final String user="mysql.user";
	    private static final String password="mysql.password";
	    private static  Connection connection = null;
	    private  static  Properties DB_PROPERTES=null;



	   public static void setConnection() {

	        try {
	        
	          DB_PROPERTES=new Properties();
	          DB_PROPERTES.load(new FileInputStream("src/main/resource/HotelDb.properties"));
	          Class.forName(DB_PROPERTES.getProperty(driver_class));
	          connection= DriverManager.getConnection(DB_PROPERTES.getProperty(url),DB_PROPERTES.getProperty(user),DB_PROPERTES.getProperty(password));
	          
	          //Class.forName("com.mysql.cj.jdbc.Driver");
	          //Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelmanage", "root", "root");

	        }
	        catch (SQLException | ClassNotFoundException | IOException e){
	            e.printStackTrace();
	        }

	    }
	    public static Connection getConnection()
	    {
	        setConnection();
	    	return connection;
	    }

	}