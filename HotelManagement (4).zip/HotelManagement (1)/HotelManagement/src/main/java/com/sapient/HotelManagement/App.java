package com.sapient.HotelManagement;

import com.sapient.HotelManagement.consoles.FrontConsole;
import com.sapient.HotelManagement.controller.GuestController;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	FrontConsole console = new FrontConsole();
    	FrontConsole.Console0();
    	
    }
}
